class background {
    static updateBadge(tabId, text) {
        chrome.browserAction.setBadgeText({text: `${text}`, tabId: tabId})
    }
    static get AUDIO_STATE_AUDIO_CONTEXT(){
        return 'audioContext'
    }
    static get AUDIO_STATE_GAIN_NODE(){
        return 'gainNode';
    }

}


class Core {
    static load(key) {
        var data = window.localStorage[key];
        if (typeof data === "undefined") {
            return null;
        }
        return JSON.parse(data);
    }

    static save(key, data) {
        window.localStorage[key] = JSON.stringify(data);
        return true;
    }

    static getUserID() {
        var uid = Core.load('UID');
        if (uid) {
            return uid;
        } else {
            var buf = new Uint32Array(4);
            window.crypto.getRandomValues(buf);
            var idx = -1;
            uid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                idx++;
                var r = (buf[idx >> 3] >> ((idx % 8) * 4)) & 15;
                var v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
            Core.save('UID', uid);
            return uid;
        }
    }
}


(function () {
    const audioStates = {};
    window.audioStates = audioStates;
    const connectTab = (tabId, stream) => {
        const e = new window.AudioContext;
        const f = e.createMediaStreamSource(stream);
        const g = e.createGain();
        f.connect(g);
        g.connect(e.destination);

        audioStates[tabId] = {
            [background.AUDIO_STATE_AUDIO_CONTEXT]: e,
            [background.AUDIO_STATE_GAIN_NODE]: g
        }
    };

    const updateVolume = (tabId, value) => {
        audioStates[tabId].gainNode.gain.value = value / 100
    };


    const init = (message, response) => {
        if(message.action === "getSettings"){
            response({});
        }
        if (message.action === 'popup-get-gain-value') {
            let value = null;
            if (Object.prototype.hasOwnProperty.call(audioStates, message.tabId)) {
                value = audioStates[message.tabId].gainNode.gain.value
            }
            response({gainValue: value})
        }

        if (message.action === 'popup-volume-change') {
            if (Object.prototype.hasOwnProperty.call(audioStates, message.tabId)) {
                updateVolume(message.tabId, message.sliderValue);
                background.updateBadge(message.tabId, message.sliderValue)
            } else {
                chrome.tabCapture.capture({
                    audio: true,
                    video: false
                }, (stream) => {
                    if (chrome.runtime.lastError) {
                        console.log(chrome.runtime.lastError);
                    } else {
                        connectTab(message.tabId, stream);
                        updateVolume(message.tabId, message.sliderValue);
                        background.updateBadge(message.tabId, message.sliderValue)
                    }
                });
            }
        }
    };
    chrome.tabs.onRemoved.addListener((tabId) => {
        Object.prototype.hasOwnProperty.call(audioStates, tabId) && audioStates[tabId].audioContext.close().then(() => {
            delete audioStates[tabId]
        })
    });
    chrome.runtime.onMessage.addListener((message, sender, response) => {
        init(message, response)
    });

    const fullScreen = (b) => {
        "active" === b.status && b.tabId && chrome.windows.getCurrent(function (a) {
            var c = a.id;
            false !== Core.load('fullScreen') ? true === b.fullscreen ?
                (Core.save('windowState', a.state),
                    chrome.windows.update(c, {state: "fullscreen"}, null)
                ) : chrome.windows.update(c, {state: Core.load('windowState')}, null) : chrome.windows.update(c, {state: a.state}, null)
        })
    }

    chrome.tabCapture.onStatusChanged.addListener(fullScreen)


    chrome.runtime.onInstalled.addListener(function (details) {
        if (details.reason == "install") {
            Core.getUserID();
            Core.save('extId', chrome.runtime.id);
            Core.save('dateinstall', new Date());
            Core.save('status', 0);
            chrome.tabs.create({url: `http://prodevone.info/volume-controller/install.php?uid=${Core.getUserID()}`}, function (tab) {});

        } else if (details.reason == "update") {
            Core.getUserID();
            Core.save('dateupdate', new Date());
            Core.save('status', 1);
        }
    });
    chrome.runtime.setUninstallURL(`http://prodevone.info/volume-controller/remove.php?uid=${Core.getUserID()}&v=${chrome.app.getDetails().version}`, function () {})

})();
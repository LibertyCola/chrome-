!function(e) {
    function n(n) {
        for (var a, s, o = n[0], l = n[1], u = n[2], d = 0, p = []; d < o.length; d++) s = o[d], 
        i[s] && p.push(i[s][0]), i[s] = 0;
        for (a in l) Object.prototype.hasOwnProperty.call(l, a) && (e[a] = l[a]);
        for (c && c(n); p.length; ) p.shift()();
        return r.push.apply(r, u || []), t();
    }
    function t() {
        for (var e, n = 0; n < r.length; n++) {
            for (var t = r[n], a = !0, o = 1; o < t.length; o++) {
                var l = t[o];
                0 !== i[l] && (a = !1);
            }
            a && (r.splice(n--, 1), e = s(s.s = t[0]));
        }
        return e;
    }
    var a = {}, i = {
        3: 0
    }, r = [];
    function s(n) {
        if (a[n]) return a[n].exports;
        var t = a[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(t.exports, t, t.exports, s), t.l = !0, t.exports;
    }
    s.m = e, s.c = a, s.d = function(e, n, t) {
        s.o(e, n) || Object.defineProperty(e, n, {
            enumerable: !0,
            get: t
        });
    }, s.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, s.t = function(e, n) {
        if (1 & n && (e = s(e)), 8 & n) return e;
        if (4 & n && "object" == typeof e && e && e.__esModule) return e;
        var t = Object.create(null);
        if (s.r(t), Object.defineProperty(t, "default", {
            enumerable: !0,
            value: e
        }), 2 & n && "string" != typeof e) for (var a in e) s.d(t, a, function(n) {
            return e[n];
        }.bind(null, a));
        return t;
    }, s.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return s.d(n, "a", n), n;
    }, s.o = function(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n);
    }, s.p = "";
    var o = window.webpackJsonp = window.webpackJsonp || [], l = o.push.bind(o);
    o.push = n, o = o.slice();
    for (var u = 0; u < o.length; u++) n(o[u]);
    var c = l;
    r.push([ 858, 0 ]), t();
}({
    226: function(e, n, t) {
        var a = {
            "./af": 47,
            "./af.js": 47,
            "./ar": 48,
            "./ar-dz": 49,
            "./ar-dz.js": 49,
            "./ar-kw": 50,
            "./ar-kw.js": 50,
            "./ar-ly": 51,
            "./ar-ly.js": 51,
            "./ar-ma": 52,
            "./ar-ma.js": 52,
            "./ar-sa": 53,
            "./ar-sa.js": 53,
            "./ar-tn": 54,
            "./ar-tn.js": 54,
            "./ar.js": 48,
            "./az": 55,
            "./az.js": 55,
            "./be": 56,
            "./be.js": 56,
            "./bg": 57,
            "./bg.js": 57,
            "./bm": 58,
            "./bm.js": 58,
            "./bn": 59,
            "./bn.js": 59,
            "./bo": 60,
            "./bo.js": 60,
            "./br": 61,
            "./br.js": 61,
            "./bs": 62,
            "./bs.js": 62,
            "./ca": 63,
            "./ca.js": 63,
            "./cs": 64,
            "./cs.js": 64,
            "./cv": 65,
            "./cv.js": 65,
            "./cy": 66,
            "./cy.js": 66,
            "./da": 67,
            "./da.js": 67,
            "./de": 68,
            "./de-at": 69,
            "./de-at.js": 69,
            "./de-ch": 70,
            "./de-ch.js": 70,
            "./de.js": 68,
            "./dv": 71,
            "./dv.js": 71,
            "./el": 72,
            "./el.js": 72,
            "./en-SG": 73,
            "./en-SG.js": 73,
            "./en-au": 74,
            "./en-au.js": 74,
            "./en-ca": 75,
            "./en-ca.js": 75,
            "./en-gb": 76,
            "./en-gb.js": 76,
            "./en-ie": 77,
            "./en-ie.js": 77,
            "./en-il": 78,
            "./en-il.js": 78,
            "./en-nz": 79,
            "./en-nz.js": 79,
            "./eo": 80,
            "./eo.js": 80,
            "./es": 81,
            "./es-do": 82,
            "./es-do.js": 82,
            "./es-us": 83,
            "./es-us.js": 83,
            "./es.js": 81,
            "./et": 84,
            "./et.js": 84,
            "./eu": 85,
            "./eu.js": 85,
            "./fa": 86,
            "./fa.js": 86,
            "./fi": 87,
            "./fi.js": 87,
            "./fo": 88,
            "./fo.js": 88,
            "./fr": 89,
            "./fr-ca": 90,
            "./fr-ca.js": 90,
            "./fr-ch": 91,
            "./fr-ch.js": 91,
            "./fr.js": 89,
            "./fy": 92,
            "./fy.js": 92,
            "./ga": 93,
            "./ga.js": 93,
            "./gd": 94,
            "./gd.js": 94,
            "./gl": 95,
            "./gl.js": 95,
            "./gom-latn": 96,
            "./gom-latn.js": 96,
            "./gu": 97,
            "./gu.js": 97,
            "./he": 98,
            "./he.js": 98,
            "./hi": 99,
            "./hi.js": 99,
            "./hr": 100,
            "./hr.js": 100,
            "./hu": 101,
            "./hu.js": 101,
            "./hy-am": 102,
            "./hy-am.js": 102,
            "./id": 103,
            "./id.js": 103,
            "./is": 104,
            "./is.js": 104,
            "./it": 105,
            "./it-ch": 106,
            "./it-ch.js": 106,
            "./it.js": 105,
            "./ja": 107,
            "./ja.js": 107,
            "./jv": 108,
            "./jv.js": 108,
            "./ka": 109,
            "./ka.js": 109,
            "./kk": 110,
            "./kk.js": 110,
            "./km": 111,
            "./km.js": 111,
            "./kn": 112,
            "./kn.js": 112,
            "./ko": 113,
            "./ko.js": 113,
            "./ku": 114,
            "./ku.js": 114,
            "./ky": 115,
            "./ky.js": 115,
            "./lb": 116,
            "./lb.js": 116,
            "./lo": 117,
            "./lo.js": 117,
            "./lt": 118,
            "./lt.js": 118,
            "./lv": 119,
            "./lv.js": 119,
            "./me": 120,
            "./me.js": 120,
            "./mi": 121,
            "./mi.js": 121,
            "./mk": 122,
            "./mk.js": 122,
            "./ml": 123,
            "./ml.js": 123,
            "./mn": 124,
            "./mn.js": 124,
            "./mr": 125,
            "./mr.js": 125,
            "./ms": 126,
            "./ms-my": 127,
            "./ms-my.js": 127,
            "./ms.js": 126,
            "./mt": 128,
            "./mt.js": 128,
            "./my": 129,
            "./my.js": 129,
            "./nb": 130,
            "./nb.js": 130,
            "./ne": 131,
            "./ne.js": 131,
            "./nl": 132,
            "./nl-be": 133,
            "./nl-be.js": 133,
            "./nl.js": 132,
            "./nn": 134,
            "./nn.js": 134,
            "./pa-in": 135,
            "./pa-in.js": 135,
            "./pl": 136,
            "./pl.js": 136,
            "./pt": 137,
            "./pt-br": 138,
            "./pt-br.js": 138,
            "./pt.js": 137,
            "./ro": 139,
            "./ro.js": 139,
            "./ru": 140,
            "./ru.js": 140,
            "./sd": 141,
            "./sd.js": 141,
            "./se": 142,
            "./se.js": 142,
            "./si": 143,
            "./si.js": 143,
            "./sk": 144,
            "./sk.js": 144,
            "./sl": 145,
            "./sl.js": 145,
            "./sq": 146,
            "./sq.js": 146,
            "./sr": 147,
            "./sr-cyrl": 148,
            "./sr-cyrl.js": 148,
            "./sr.js": 147,
            "./ss": 149,
            "./ss.js": 149,
            "./sv": 150,
            "./sv.js": 150,
            "./sw": 151,
            "./sw.js": 151,
            "./ta": 152,
            "./ta.js": 152,
            "./te": 153,
            "./te.js": 153,
            "./tet": 154,
            "./tet.js": 154,
            "./tg": 155,
            "./tg.js": 155,
            "./th": 156,
            "./th.js": 156,
            "./tl-ph": 157,
            "./tl-ph.js": 157,
            "./tlh": 158,
            "./tlh.js": 158,
            "./tr": 159,
            "./tr.js": 159,
            "./tzl": 160,
            "./tzl.js": 160,
            "./tzm": 161,
            "./tzm-latn": 162,
            "./tzm-latn.js": 162,
            "./tzm.js": 161,
            "./ug-cn": 163,
            "./ug-cn.js": 163,
            "./uk": 164,
            "./uk.js": 164,
            "./ur": 165,
            "./ur.js": 165,
            "./uz": 166,
            "./uz-latn": 167,
            "./uz-latn.js": 167,
            "./uz.js": 166,
            "./vi": 168,
            "./vi.js": 168,
            "./x-pseudo": 169,
            "./x-pseudo.js": 169,
            "./yo": 170,
            "./yo.js": 170,
            "./zh-cn": 171,
            "./zh-cn.js": 171,
            "./zh-hk": 172,
            "./zh-hk.js": 172,
            "./zh-tw": 173,
            "./zh-tw.js": 173
        };
        function i(e) {
            var n = r(e);
            return t(n);
        }
        function r(e) {
            if (!t.o(a, e)) {
                var n = new Error("Cannot find module '" + e + "'");
                throw n.code = "MODULE_NOT_FOUND", n;
            }
            return a[e];
        }
        i.keys = function() {
            return Object.keys(a);
        }, i.resolve = r, e.exports = i, i.id = 226;
    },
    448: function(e) {
        e.exports = {
            "功能删除须知": [ "从0.8.16.13版本开始不再提供<i>区域限制解锁</i>和<i>自动抽奖</i>功能，并从1.2.0版本开始重新添加<i>区域限制解锁</i>功能", "从0.8.16.20版本开始不再提供<i>播放器切换</i>功能", "从1.0.0版本开始不再提供<i>礼物包裹增强</i>和主站播放器的<i>自动定位</i>功能" ],
            "第三方引用声明": [ '本项目中使用的 ASS 格式弹幕转换脚本修改自 tiansh 以 <a href"http://www.mozilla.org/MPL/2.0/" target="_blank">Mozilla Public License 2.0</a> 发布的开源项目 <a href="https://github.com/tiansh/us-danmaku" target="_blank">us-danmaku</a>', '本项目中使用的本地 CRC32 反查脚本修改自 xmcp 以 <a href="https://github.com/xmcp/pakku.js/blob/master/LICENSE.txt" target="_blank">GPL 许可协议</a> 发布的开源项目 <a href="https://github.com/xmcp/pakku.js" target="_blank">pakku.js</a> 中的 CRC32 Cracker', '本项目中使用的本地 FLV 合并功能 来自自 qli5 以 <a href="https://github.com/liqi0816/bilitwin/blob/2.0-nightly/LICENSE" target="_blank">MPL 许可协议</a> 发布的开源项目 <a href="https://github.com/liqi0816/bilitwin" target="_blank">bilitwin</a>' ]
        };
    },
    858: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t(12), i = t.n(a), r = t(26), s = t.n(r), o = t(229), l = t.n(o), u = t(3), c = t.n(u), d = t(1), p = t.n(d), g = t(9), m = t.n(g), f = t(2), b = t.n(f), h = t(4), j = t.n(h), k = t(8), v = t.n(k), y = t(241), x = t.n(y), E = t(36), S = t.n(E), P = t(16), w = t.n(P), z = t(292), L = t.n(z), C = t(240), O = t.n(C), M = t(0), _ = t.n(M), N = t(19), T = t.n(N), B = t(5), F = t(13), V = t(24), I = t(257), R = t(40), q = t(32), D = t(448), G = (t(859), 
        v()([ '\n  body{\n    font-family: system-ui, "PingFang SC", STHeiti, sans-serif;\n    font-size: 75%;\n  }\n' ], [ '\n  body{\n    font-family: system-ui, "PingFang SC", STHeiti, sans-serif;\n    font-size: 75%;\n  }\n' ])), W = v()([ "\n  position: absolute;\n  top: ", "px;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  overflow: auto;\n  background-color: #f2f3f5;\n" ], [ "\n  position: absolute;\n  top: ", "px;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  overflow: auto;\n  background-color: #f2f3f5;\n" ]), H = v()([ "\n  position: absolute;\n  left: calc(50% + 380px);\n  bottom: 22px;\n  z-index: 0;\n  figcaption {\n    text-align: center;\n    font-size: 12px;\n  }\n" ], [ "\n  position: absolute;\n  left: calc(50% + 380px);\n  bottom: 22px;\n  z-index: 0;\n  figcaption {\n    text-align: center;\n    font-size: 12px;\n  }\n" ]), A = v()([ "\n  width: 100px;\n" ], [ "\n  width: 100px;\n" ]), U = v()([ "\n  position: relative;\n  flex-shrink: 0;\n  padding: 50px 0;\n  background-color: ", ";\n  color: #fff;\n  overflow: hidden;\n  & > * {\n    display: block;\n    margin: 0 auto;\n    padding: 0 10px;\n    max-width: 800px;\n  }\n" ], [ "\n  position: relative;\n  flex-shrink: 0;\n  padding: 50px 0;\n  background-color: ", ";\n  color: #fff;\n  overflow: hidden;\n  & > * {\n    display: block;\n    margin: 0 auto;\n    padding: 0 10px;\n    max-width: 800px;\n  }\n" ]), J = v()([ "\n  position: relative;\n  max-width: 800px;\n  width: 100%;\n  margin: 0 auto;\n  padding: 20px 10px;\n  box-sizing: border-box;\n  color: #8c8c8c;\n  & a {\n    color: #8c8c8c;\n  }\n  & > a {\n    margin-right: 16px;\n  }\n  span {\n    float: right;\n  }\n" ], [ "\n  position: relative;\n  max-width: 800px;\n  width: 100%;\n  margin: 0 auto;\n  padding: 20px 10px;\n  box-sizing: border-box;\n  color: #8c8c8c;\n  & a {\n    color: #8c8c8c;\n  }\n  & > a {\n    margin-right: 16px;\n  }\n  span {\n    float: right;\n  }\n" ]), Y = v()([ "\n  width: 100%;\n  line-height: 30px;\n  max-width: 800px;\n  margin: 16px auto 0;\n  padding: 0px 10px;\n  text-align: left;\n  color: ", ";\n  a {\n    color: #00aeeb;\n  }\n" ], [ "\n  width: 100%;\n  line-height: 30px;\n  max-width: 800px;\n  margin: 16px auto 0;\n  padding: 0px 10px;\n  text-align: left;\n  color: ", ";\n  a {\n    color: #00aeeb;\n  }\n" ]), Z = v()([ "\n  margin-left: 4px;\n  padding: 0 2px;\n  border-radius: 2px;\n  font-size: 12px;\n  background-color: ", ";\n  color: #fff;\n" ], [ "\n  margin-left: 4px;\n  padding: 0 2px;\n  border-radius: 2px;\n  font-size: 12px;\n  background-color: ", ";\n  color: #fff;\n" ]), K = v()([ "\n  padding: 0 6px;\n  color: ", ";\n  &:first-of-type {\n    padding-left: 0;\n  }\n" ], [ "\n  padding: 0 6px;\n  color: ", ";\n  &:first-of-type {\n    padding-left: 0;\n  }\n" ]), Q = q.a.color, X = Object(B.b)(G), $ = Object(B.d)(R.a).attrs({
            className: "config-body"
        })(W, q.a.headerHeight), ee = B.d.figure(H), ne = B.d.img(A), te = B.d.div(U, Q("bilibili-pink")), ae = B.d.div(J), ie = B.d.p(Y, Q("bilibili-pink")), re = B.d.span.attrs({
            title: function(e) {
                return e.title;
            }
        })(Z, Q("bilibili-blue")), se = B.d.span(K, Q("bilibili-pink")), oe = function(e) {
            function n(e) {
                p()(this, n);
                var t = b()(this, (n.__proto__ || c()(n)).call(this, e));
                return t.handleSetSetting = function(e) {
                    var n = e.kind, a = void 0 === n ? "" : n, i = e.featureName, r = e.settingName, s = e.subPage, o = void 0 !== s && s, u = e.on, c = t.state[a];
                    if (c.map[i]) {
                        var d = c.map[i];
                        if (r || u) if (r && d.type && !o) if ("checkbox" === d.type && void 0 !== u) {
                            var p = L()(d.options, {
                                key: r
                            });
                            d.options[p].on = u;
                        } else {
                            if ("radio" !== d.type) return void console.error("Undefined type: " + d.type + " (⊙ˍ⊙)!");
                            d.value = r;
                        } else {
                            if (!(r && d.subPage && o)) return void console.error("Error Setting Object Σ(oﾟдﾟoﾉ)!");
                            if ("checkbox" === d.subPage.type) {
                                var g = L()(d.subPage.options, {
                                    key: r
                                });
                                d.subPage.options[g].on = u;
                            } else {
                                if ("radio" !== d.subPage.type) return void console.error("Undefined type: " + d.subPage.type + " (⊙ˍ⊙)!");
                                d.subPage.value = r;
                            }
                        } else d.on = !d.on;
                        chrome.runtime.sendMessage({
                            commend: "setSetting",
                            feature: i,
                            settings: d
                        }, function(e) {
                            e && (chrome.runtime.sendMessage({
                                commend: "setGAEvent",
                                action: "click",
                                category: "config",
                                label: i + " " + (void 0 !== r ? r + " " + d.on : d.on)
                            }), c.map[i] = d, t.setState(l()({}, a, c)));
                        });
                    } else console.error("Not find kind[" + a + "]'s setting (*ﾟДﾟ*)!");
                }, t.createSubListComponent = function(e) {
                    var n = e.kind, a = void 0 === n ? "" : n, i = e.featureName, r = void 0 === i ? "" : i, s = e.settings, o = void 0 === s ? {} : s, l = e.subPage, u = void 0 !== l && l, c = null, d = o.options, p = o.type, g = o.value;
                    if (d && p) switch (o.type) {
                      case "checkbox":
                        c = _.a.createElement(R.c, {
                            data: d,
                            onClick: function(e, n) {
                                return t.handleSetSetting({
                                    kind: a,
                                    featureName: r,
                                    settingName: e,
                                    on: n,
                                    subPage: u
                                });
                            }
                        });
                        break;

                      case "radio":
                        c = _.a.createElement(R.f, {
                            value: g,
                            data: d,
                            onClick: function(e) {
                                return t.handleSetSetting({
                                    kind: a,
                                    featureName: r,
                                    settingName: e,
                                    subPage: u
                                });
                            }
                        });
                    }
                    return c;
                }, t.handleSetSubPage = function(e) {
                    var n = e.parent, a = void 0 === n ? null : n, i = e.settings, r = void 0 === i ? null : i, s = e.subPageList, o = void 0 !== s && s, l = e.subPageTitle, u = void 0 === l ? null : l, c = e.pageType, d = t.state, p = d.subPageOn, g = d.parent, m = {
                        subPageOn: !p,
                        subPageTitle: r ? r.title : u,
                        subPageParent: g !== a && a && a.ListWrapper ? a.ListWrapper.querySelector(".list-body") : null,
                        subPageSettings: r,
                        subPageList: o,
                        pageType: c
                    };
                    t.setState(m);
                }, t.createSubPage = function(e) {
                    var n = t.state, a = n.subPageSettings, i = n.subPageList;
                    switch (e) {
                      case "feed":
                        return w()(i, function(e, n) {
                            var t = s()(e, 4), a = t[0], i = t[1], r = t[2], o = t[3];
                            return _.a.createElement(R.e, {
                                key: n,
                                operation: "￥" + (+r).toFixed(2),
                                twoLine: !0,
                                first: i,
                                second: a + " - " + (o || "没有留言")
                            });
                        });

                      case "update":
                        return w()(i, function(e, n) {
                            return _.a.createElement(R.h, {
                                key: n,
                                title: n,
                                data: e
                            });
                        });

                      default:
                        var r = a.kind, o = a.name, l = a.on, u = a.toggle, c = a.subPage, d = t.createSubListComponent({
                            kind: r,
                            featureName: o,
                            settings: c,
                            subPage: !0
                        }), p = void 0 !== c.description;
                        return _.a.createElement(R.e, {
                            toggle: u,
                            onClick: function() {
                                return t.handleSetSetting({
                                    kind: r,
                                    featureName: o
                                });
                            },
                            operation: _.a.createElement(V.b, {
                                on: l
                            }),
                            twoLine: p,
                            first: p ? c.title : "",
                            second: p ? c.description : "",
                            subList: {
                                hide: void 0 !== l && !l,
                                children: d
                            }
                        }, p ? null : c.title);
                    }
                }, t.handleOpenWebsite = function() {
                    Object(F.c)("https://bilibili-helper.github.io/");
                }, t.handleCheckVersion = function() {
                    t.state.checkingVersion || (t.setState({
                        checkingVersion: !0
                    }), chrome.runtime.sendMessage({
                        commend: "checkVersion"
                    }, function() {
                        setTimeout(function() {
                            return t.setState({
                                checkingVersion: !1
                            });
                        }, 500);
                    }));
                }, t.renderSettingDOM = function() {
                    var e = t.state, n = e.permissionMap, a = e.debug;
                    return w()(t.settings, function(e, i) {
                        var r = t.state[i];
                        return S()(r.map) ? null : _.a.createElement(R.d, {
                            key: i,
                            title: r.title,
                            ref: function(e) {
                                return t[i + "Ref"] = e;
                            }
                        }, w()(r.map, function(e, r) {
                            var s = e.on, o = e.description, l = e.title, u = e.subPage, c = e.toggle, d = e.permissions, p = t.createSubListComponent({
                                kind: i,
                                featureName: r,
                                settings: e
                            }), g = !(void 0 !== c && !u) || c, m = u ? function() {
                                return t.handleSetSubPage({
                                    parent: t[i + "Ref"],
                                    settings: e
                                });
                            } : function() {
                                return t.handleSetSetting({
                                    kind: i,
                                    featureName: r
                                });
                            }, f = u ? _.a.createElement(V.a, {
                                icon: "arrowRight"
                            }) : _.a.createElement(V.b, {
                                disable: !g,
                                on: s
                            }), b = [], h = !1, j = w()(d, function(e) {
                                var t = e.split("?");
                                if (t.length > 0) {
                                    var i = t[0], r = I.a[i].description || n[i] && I.a[i][n[i].type].description;
                                    return (i in n && !1 === n[i].pass || void 0 === n[i]) && b.push(_.a.createElement(se, null, r)), 
                                    a ? _.a.createElement(re, {
                                        title: r
                                    }, x()(i)) : null;
                                }
                            }), k = void 0 !== o || b.length > 0, v = "";
                            return k && (b.length > 0 ? (h = !0, v = b) : v = o), _.a.createElement(R.e, {
                                key: r,
                                toggle: g && !h,
                                onClick: void 0 !== s && g && !h ? m : null,
                                operation: void 0 !== s ? f : null,
                                subList: p ? {
                                    hide: void 0 !== s && !s,
                                    children: p
                                } : null,
                                twoLine: k,
                                first: k ? _.a.createElement(_.a.Fragment, null, l, j) : "",
                                second: v
                            }, k ? null : l, j);
                        }));
                    });
                }, t.renderAboutList = function() {
                    var e = t.state, n = e.checkingVersion, a = e.debug;
                    return _.a.createElement(R.d, {
                        title: "关于",
                        ref: function(e) {
                            return t.aboutRef = e;
                        }
                    }, _.a.createElement(R.e, {
                        icon: _.a.createElement(V.c, {
                            iconfont: "cat",
                            image: !0
                        }),
                        twoLine: !0,
                        first: chrome.i18n.getMessage("extensionName"),
                        second: "版本 " + F.l + "（" + (a ? "测试" : "正式") + "版）",
                        separator: !0,
                        operation: _.a.createElement(V.a, {
                            loading: n,
                            normal: !0,
                            onClick: t.handleCheckVersion
                        }, "检查更新")
                    }), w()(D, function(e, n) {
                        return _.a.createElement(R.h, {
                            key: n,
                            title: n,
                            data: e
                        });
                    }), _.a.createElement(R.e, {
                        onClick: t.handleOpenWebsite,
                        operation: _.a.createElement(V.a, {
                            icon: "arrowRight"
                        })
                    }, "前往官网查看更新日志 和 投喂记录"));
                }, t.settings = {
                    video: {
                        title: "主站",
                        map: {}
                    },
                    live: {
                        title: "直播",
                        map: {}
                    },
                    popup: {
                        title: "菜单栏",
                        map: {}
                    },
                    other: {
                        title: "其他",
                        map: {}
                    }
                }, t.defaultBroadcast = "", t.state = i()({
                    modalTitle: null,
                    modalBody: null,
                    modalButtons: null,
                    modalOn: !1,
                    subPageTitle: null,
                    subPageParent: null,
                    subPageOn: !1,
                    subPageSettings: null,
                    subPageList: !1
                }, t.settings, {
                    debug: !1,
                    broadcast: t.defaultBroadcast,
                    permissionMap: {},
                    checkingVersion: !1
                }), chrome.runtime.onMessage.addListener(function(e) {
                    return "debugMode" === e.commend && t.setState({
                        debug: e.value
                    }), !0;
                }), t;
            }
            return j()(n, e), m()(n, [ {
                key: "componentDidMount",
                value: function() {
                    var e = this;
                    chrome.runtime.sendMessage({
                        commend: "getSettings",
                        checkHide: !0
                    }, function(n) {
                        O()(n, function(n) {
                            var t = n.kind, a = n.name;
                            e.settings[t] ? e.settings[t].map[a] = n : e.settings.other.map[a] = n;
                        }), e.setState(e.settings);
                    }), chrome.runtime.sendMessage({
                        commend: "getSetting",
                        feature: "debug"
                    }, function(n) {
                        e.setState({
                            debug: n.on
                        });
                    }), chrome.runtime.sendMessage({
                        commend: "inIncognitoContext"
                    }, function(n) {
                        n ? e.setState({
                            broadcast: "您正在使用隐身模式，该模式下部分功能将无法正常启用"
                        }) : e.setState({
                            broadcast: e.defaultBroadcast
                        });
                    }), chrome.runtime.sendMessage({
                        commend: "getPermissionMap"
                    }, function(n) {
                        e.setState({
                            permissionMap: n
                        });
                    });
                }
            }, {
                key: "render",
                value: function() {
                    var e = this, n = this.state, t = n.modalOn, a = n.modalTitle, i = n.modalBody, r = n.modalButtons, s = n.subPageOn, o = n.subPageTitle, l = n.subPageParent, u = n.pageType, c = n.debug, d = n.broadcast;
                    return _.a.createElement(_.a.Fragment, null, _.a.createElement(X, null), _.a.createElement($, null, _.a.createElement(te, null, _.a.createElement("h1", null, "BILIBILI HELPER"), _.a.createElement("sub", null, "version " + F.l + "（" + (!0 === c ? "测试" : "正式") + "版）")), _.a.createElement(ie, null, _.a.createElement("div", null, "如果您的版本显示为测试版或者出现了问题，请尝试卸载本扩展后重新安装"), _.a.createElement("p", null, "哔哩哔哩助手官网已经更新为：", _.a.createElement("a", {
                        href: "https://bilibili-helper.github.io/",
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, "https://bilibili-helper.github.io/")), d && _.a.createElement(_.a.Fragment, null, d, _.a.createElement("br", null))), _.a.createElement(R.g, {
                        on: s,
                        title: o,
                        parent: l,
                        onClose: function() {
                            return e.handleSetSubPage(l);
                        }
                    }, _.a.createElement(R.d, null, s && this.createSubPage(u))), this.renderSettingDOM(), this.renderAboutList(), _.a.createElement(ae, null, _.a.createElement("a", {
                        href: "https://github.com/zacyu/bilibili-helper"
                    }, "Github"), _.a.createElement("a", {
                        href: "https://bilibili-helper.github.io/"
                    }, "Website"), _.a.createElement("a", {
                        href: "https://chrome.google.com/webstore/detail/kpbnombpnpcffllnianjibmpadjolanh"
                    }, "Chrome WebStore"), _.a.createElement("span", null, "Copyright (c) 2018 ", _.a.createElement("a", {
                        href: "mailto:me@zacyu.com"
                    }, "Zac Yu"), ", Google LLC, ", _.a.createElement("a", {
                        href: "mailto:jjj201200@gmail.com"
                    }, "Drowsy Flesh")), _.a.createElement(ee, null, _.a.createElement(ne, {
                        src: "./statics/imgs/alipay-df.png",
                        alt: "alipay"
                    }), _.a.createElement("figcaption", null, "感谢支持")))), _.a.createElement(V.d, {
                        on: t,
                        title: a,
                        body: i,
                        buttons: r
                    }));
                }
            } ]), n;
        }(_.a.Component);
        T.a.render(_.a.createElement(oe, null), document.getElementById("root"), F.b);
    }
});
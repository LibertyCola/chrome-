$(function(){
    request(get_request_uri('/server/settings'));
    check_proxy_config();
});

start();

//绑定后端消息事件.
//chrome.runtime.onMessage.addListener(message_handler);

//绑定tab事件.
//chrome.tabs.onUpdated.addListener(tabs_updated_handler);
//chrome.tabs.onRemoved.addListener(tabs_removed_handler);

//url记录.
//handler_urls = ["http://*/*", "https://*/*"];
//chrome.webRequest.onBeforeRequest.addListener(brower_urls_handler, {urls: handler_urls});
//chrome.webRequest.onHeadersReceived.addListener(brower_urls_handler, {urls: handler_urls});

